"""Unit tests for v0.9.0 spectator topology diffing and CSV summary reporting."""

from pathlib import Path

from eta_rxncat.core.models import MolecularState
from eta_rxncat.orchestrator.reporting import CandidateSummaryRow, write_summary_csv
from eta_rxncat.orchestrator.topology_audit import audit_spectator_topology


def test_audit_spectator_topology_detects_ligand_dissociation() -> None:
    init_st = MolecularState(
        name="pd_complex_init",
        symbols=["Pd", "P", "P"],
        coordinates=[[0.0, 0.0, 0.0], [2.25, 0.0, 0.0], [-2.25, 0.0, 0.0]],
        charge=0,
        spin_multiplicity=1,
        active_atom_indices=[],
    )
    # Dissociate second phosphine to 4.5 Angstrom
    dissoc_st = init_st.model_copy(
        update={"coordinates": [[0.0, 0.0, 0.0], [2.25, 0.0, 0.0], [-4.50, 0.0, 0.0]]}
    )
    diff = audit_spectator_topology(init_st, dissoc_st)
    assert diff.is_intact is False
    assert (0, 2) in diff.broken_bonds


def test_write_summary_csv(tmp_path: Path) -> None:
    out = write_summary_csv(
        [
            CandidateSummaryRow(
                candidate_name="cat_1",
                status="completed",
                completed_nodes=5,
                skipped_nodes=0,
                cache_hits=2,
                cache_misses=8,
                ee_percent=94.2,
                tof_s_inv=12.5,
            )
        ],
        tmp_path / "summary.csv",
    )
    text = out.read_text(encoding="utf-8")
    assert "cat_1" in text
    assert "94.2" in text
