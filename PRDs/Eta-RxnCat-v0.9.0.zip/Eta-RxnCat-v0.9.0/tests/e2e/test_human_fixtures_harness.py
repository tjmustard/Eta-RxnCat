"""End-to-end test harness discovering and running human-authored ReactionGraph fixtures."""

from pathlib import Path

import pytest

from eta_rxncat.core.reaction_graph import ReactionGraph
from eta_rxncat.engines.rdkit_xtb import RDKitFFEngine
from eta_rxncat.orchestrator.scheduler import GraphOrchestrator
from eta_rxncat.store.artifact_store import ArtifactStore

FIXTURES_DIR = Path(__file__).parent / "fixtures"


@pytest.mark.e2e
def test_all_human_yaml_fixtures_validate() -> None:
    yaml_files = sorted(FIXTURES_DIR.glob("*.y*ml"))
    assert len(yaml_files) >= 1
    for yf in yaml_files:
        graph = ReactionGraph.from_file(yf)
        assert len(graph.nodes) >= 1


@pytest.mark.e2e
def test_human_fixture_smoke_execution(tmp_path: Path) -> None:
    # Runs any fixture explicitly tagged with metadata/description smoke or single-state GS
    sample = FIXTURES_DIR / "example_reaction_graph.yaml"
    graph = ReactionGraph.from_file(sample)
    # Override stages to fast UFF for CI smoke validation of the harness
    from eta_rxncat.core.models import StageConfig, StageKind

    smoke_graph = graph.model_copy(
        update={
            "default_stages": [
                StageConfig(stage=StageKind.GEOMETRY_OPT, engine="rdkit_ff", method="UFF"),
                StageConfig(stage=StageKind.FREQUENCY, engine="rdkit_ff", method="UFF"),
            ]
        }
    )
    orch = GraphOrchestrator(lambda _stg: RDKitFFEngine("UFF"), store=ArtifactStore(tmp_path / "e2e.sqlite"))
    rep = orch.run(smoke_graph)
    assert len(rep.completed_nodes) == len(smoke_graph.nodes)
