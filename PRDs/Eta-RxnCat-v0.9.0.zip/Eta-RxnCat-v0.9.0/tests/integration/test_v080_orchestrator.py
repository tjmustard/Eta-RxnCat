"""Integration tests for v0.8.0 priority-gated orchestrator, crash resume, and incremental solvation."""

from pathlib import Path

from eta_rxncat.core.models import (
    AtomMappingSpec,
    MolecularState,
    NodeKind,
    SolvationSpec,
    StageConfig,
    StageKind,
)
from eta_rxncat.core.reaction_graph import (
    PruningRule,
    ReactionGraph,
    ReactionNode,
    TemplateGeometry,
)
from eta_rxncat.engines.rdkit_xtb import RDKitFFEngine
from eta_rxncat.orchestrator.energetic_span import compute_energetic_span
from eta_rxncat.orchestrator.scheduler import GraphOrchestrator
from eta_rxncat.store.artifact_store import ArtifactStore


def _water(name: str = "water") -> MolecularState:
    return MolecularState(
        name=name,
        symbols=["O", "H", "H"],
        coordinates=[
            [0.0, 0.0, 0.1173],
            [0.0, 0.7572, -0.4692],
            [0.0, -0.7572, -0.4692],
        ],
        charge=0,
        spin_multiplicity=1,
    )


def test_orchestrator_priority_pruning_and_incremental_stage_caching(tmp_path: Path) -> None:
    store = ArtifactStore(tmp_path / "cache.sqlite")
    orch = GraphOrchestrator(lambda _stg: RDKitFFEngine("UFF"), store=store)

    w = _water()
    tmpl = TemplateGeometry(
        template_id="t1",
        structure=w,
        mapping=AtomMappingSpec(keep_atoms=[0, 1, 2], alignment_atoms=[0, 1, 2]),
    )

    graph = ReactionGraph(
        name="incremental_test",
        default_stages=[
            StageConfig(stage=StageKind.GEOMETRY_OPT, engine="rdkit_ff", method="UFF"),
            StageConfig(stage=StageKind.FREQUENCY, engine="rdkit_ff", method="UFF"),
        ],
        nodes=[
            ReactionNode(node_id="react", label="Reactant", kind=NodeKind.REACTANT, priority=1, templates=[tmpl]),
            ReactionNode(node_id="prod", label="Product", kind=NodeKind.PRODUCT, priority=1, templates=[tmpl]),
            ReactionNode(node_id="off_cycle", label="Off-cycle", kind=NodeKind.OFF_CYCLE_SINK, priority=2, templates=[tmpl]),
        ],
        pruning_rules=[
            PruningRule(
                rule_id="fail_gate",
                metric="delta_g_dagger_kcal",
                reference_node_id="react",
                target_node_id="prod",
                operator="lt",
                threshold=-50.0,
                on_fail="skip_remaining_nodes",
            )
        ],
    )

    rep1 = orch.run(graph)
    assert rep1.completed_nodes == ["react", "prod"]
    assert rep1.skipped_nodes == ["off_cycle"]

    graph_with_sp = graph.model_copy(
        update={
            "default_stages": [
                *graph.default_stages,
                StageConfig(
                    stage=StageKind.SINGLE_POINT,
                    engine="rdkit_ff",
                    method="UFF",
                    solvation=SolvationSpec(model="alpb", solvent="water"),
                ),
            ]
        }
    )
    rep2 = orch.run(graph_with_sp)
    assert rep2.cache_hits >= 4


def test_energetic_span_model_tof() -> None:
    res = compute_energetic_span(
        intermediate_ids=["I1", "I2"],
        intermediate_gibbs_ha=[-100.000, -100.010],
        ts_ids=["TS1", "TS2"],
        ts_gibbs_ha=[-99.975, -99.980],
        delta_g_rxn_kcal=-15.0,
    )
    assert res.tdi_node_id == "I1"
    assert res.tdts_node_id == "TS1"
    assert res.tof_esm_s_inv > 0.0
