"""CSV and JSON summary report exporters for screened ReactionGraph ensembles."""

from __future__ import annotations

import csv
from pathlib import Path

from pydantic import BaseModel

from eta_rxncat.orchestrator.scheduler import WorkflowExecutionReport


class CandidateSummaryRow(BaseModel):
    """Single row in a multi-candidate catalytic screening CSV table."""

    candidate_name: str
    status: str
    completed_nodes: int
    skipped_nodes: int
    cache_hits: int
    cache_misses: int
    delta_g_dagger_kcal: float | None = None
    ddg_dagger_kcal: float | None = None
    ee_percent: float | None = None
    tof_s_inv: float | None = None
    notes: str = ""


def write_summary_csv(rows: list[CandidateSummaryRow], csv_path: Path | str) -> Path:
    """Export ranked candidate metrics to a deterministic CSV file."""
    out = Path(csv_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = list(CandidateSummaryRow.model_fields.keys())
    with out.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row.model_dump())
    return out


def report_to_summary_row(
    report: WorkflowExecutionReport,
    *,
    delta_g_dagger_kcal: float | None = None,
    ddg_dagger_kcal: float | None = None,
    ee_percent: float | None = None,
    tof_s_inv: float | None = None,
) -> CandidateSummaryRow:
    """Convert a WorkflowExecutionReport into a tabular CandidateSummaryRow."""
    status = "pruned" if report.skipped_nodes else "completed"
    return CandidateSummaryRow(
        candidate_name=report.graph_name,
        status=status,
        completed_nodes=len(report.completed_nodes),
        skipped_nodes=len(report.skipped_nodes),
        cache_hits=report.cache_hits,
        cache_misses=report.cache_misses,
        delta_g_dagger_kcal=delta_g_dagger_kcal,
        ddg_dagger_kcal=ddg_dagger_kcal,
        ee_percent=ee_percent,
        tof_s_inv=tof_s_inv,
        notes="; ".join(report.pruning_messages),
    )
