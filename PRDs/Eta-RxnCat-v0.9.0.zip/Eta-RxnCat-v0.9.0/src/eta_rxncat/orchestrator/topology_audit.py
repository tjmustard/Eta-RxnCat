"""Covalent-connectivity graph diffing to flag unexpected ligand dissociation or mechanism switches."""

from __future__ import annotations

import numpy as np
from pydantic import BaseModel

from eta_rxncat.core.models import MolecularState

_COVALENT_RADII_ANGSTROM: dict[str, float] = {
    "H": 0.31, "B": 0.84, "C": 0.76, "N": 0.71, "O": 0.66, "F": 0.57,
    "P": 1.07, "S": 1.05, "Cl": 1.02, "Br": 1.20, "I": 1.39,
    "Ti": 1.60, "Fe": 1.32, "Ni": 1.24, "Cu": 1.32, "Zr": 1.75,
    "Ru": 1.46, "Rh": 1.42, "Pd": 1.39, "Ir": 1.41, "Pt": 1.36,
}


class TopologyDiffReport(BaseModel):
    """Comparison of covalent bond graphs before and after optimization."""

    is_intact: bool
    broken_bonds: list[tuple[int, int]]
    formed_bonds: list[tuple[int, int]]
    warnings: list[str]


def infer_bond_set(
    state: MolecularState,
    scale_factor: float = 1.25,
) -> set[tuple[int, int]]:
    """Infer covalent/coordination edges using scaled sum of covalent radii."""
    coords = state.coords_array()
    n = len(state.symbols)
    bonds: set[tuple[int, int]] = set()
    for i in range(n):
        r_i = _COVALENT_RADII_ANGSTROM.get(state.symbols[i], 1.20)
        for j in range(i + 1, n):
            r_j = _COVALENT_RADII_ANGSTROM.get(state.symbols[j], 1.20)
            dist = float(np.linalg.norm(coords[i] - coords[j]))
            if dist <= scale_factor * (r_i + r_j):
                bonds.add((i, j))
    return bonds


def audit_spectator_topology(
    initial_state: MolecularState,
    optimized_state: MolecularState,
    *,
    scale_factor: float = 1.25,
) -> TopologyDiffReport:
    """Detect bond changes outside active_atom_indices (e.g., unintended ligand dissociation)."""
    active_set = set(initial_state.active_atom_indices)
    b_init = infer_bond_set(initial_state, scale_factor=scale_factor)
    b_opt = infer_bond_set(optimized_state, scale_factor=scale_factor)

    broken = sorted(
        edge for edge in (b_init - b_opt) if edge[0] not in active_set or edge[1] not in active_set
    )
    formed = sorted(
        edge for edge in (b_opt - b_init) if edge[0] not in active_set or edge[1] not in active_set
    )

    warnings: list[str] = []
    if broken:
        warnings.append(f"Spectator bonds broken during optimization: {broken}")
    if formed:
        warnings.append(f"Unexpected spectator bonds formed during optimization: {formed}")

    return TopologyDiffReport(
        is_intact=(len(broken) == 0 and len(formed) == 0),
        broken_bonds=broken,
        formed_bonds=formed,
        warnings=warnings,
    )
