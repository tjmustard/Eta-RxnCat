"""Priority-ordered ReactionGraph DAG scheduler with stage-decomposed cache integration."""

from __future__ import annotations

from pathlib import Path
from typing import Callable

import numpy as np
from pydantic import BaseModel

from eta_rxncat.conformers.ensemble import build_boltzmann_ensemble, generate_conformers
from eta_rxncat.core.models import (
    MolecularState,
    NodeKind,
    StageConfig,
    StageKind,
)
from eta_rxncat.core.reaction_graph import ReactionGraph, ReactionNode
from eta_rxncat.core.thermo import compute_thermochemistry
from eta_rxncat.engines.base import PotentialEngine
from eta_rxncat.optimize.gs_optimizer import optimize_ground_state
from eta_rxncat.optimize.ts_optimizer import (
    analyze_vibrational_modes,
    optimize_transition_state,
    validate_transition_state_modes,
)
from eta_rxncat.orchestrator.selectivity import evaluate_pruning_rules
from eta_rxncat.store.artifact_store import ArtifactStore, StageCacheKey


class WorkflowExecutionReport(BaseModel):
    """Summary of executed, cached, and priority-pruned nodes."""

    graph_name: str
    node_gibbs_hartree: dict[str, float]
    completed_nodes: list[str]
    skipped_nodes: list[str]
    cache_hits: int
    cache_misses: int
    pruning_messages: list[str]


class GraphOrchestrator:
    """Executes ReactionGraph nodes by priority tier with stage-level caching and adaptive pruning."""

    def __init__(
        self,
        engine_factory: Callable[[StageConfig], PotentialEngine],
        store: ArtifactStore | None = None,
    ) -> None:
        self.engine_factory = engine_factory
        self.store = store or ArtifactStore()
        self.cache_hits = 0
        self.cache_misses = 0

    def _run_node(self, graph: ReactionGraph, node: ReactionNode) -> float:
        tmpl = sorted(node.templates, key=lambda t: t.priority_rank)[0]
        cur_states: list[MolecularState] = [tmpl.structure]
        stages = graph.effective_stages(node.node_id)
        is_ts = node.kind == NodeKind.TRANSITION_STATE

        latest_energies: list[float] = []
        latest_hessians: list[np.ndarray | None] = [None]

        for stg in stages:
            engine = self.engine_factory(stg)
            if stg.stage == StageKind.CONFORMER_SEARCH:
                key = StageCacheKey.build(cur_states[0], stg)
                cached = self.store.get(key)
                if cached is not None:
                    self.cache_hits += 1
                    cur_states = [MolecularState.model_validate(c) for c in cached["conformers"]]
                else:
                    self.cache_misses += 1
                    num_confs = int(stg.extra_options.get("num_confs", 10))
                    cur_states = generate_conformers(cur_states[0], num_confs=num_confs)
                    self.store.put(
                        key,
                        stg,
                        {"conformers": [c.model_dump(mode="json") for c in cur_states]},
                    )
                latest_hessians = [None] * len(cur_states)

            elif stg.stage == StageKind.GEOMETRY_OPT:
                next_states: list[MolecularState] = []
                next_energies: list[float] = []
                next_hess: list[np.ndarray | None] = []
                for st in cur_states:
                    key = StageCacheKey.build(st, stg)
                    cached = self.store.get(key)
                    if cached is not None:
                        self.cache_hits += 1
                        opt_st = MolecularState.model_validate(cached["optimized_state"])
                        e_ha = float(cached["electronic_energy_hartree"])
                        h_arr = (
                            np.asarray(cached["hessian_hartree_per_bohr2"], dtype=np.float64)
                            if cached.get("hessian_hartree_per_bohr2") is not None
                            else None
                        )
                    else:
                        self.cache_misses += 1
                        if is_ts:
                            opt_st, e_ha, h_arr = optimize_transition_state(st, engine)
                            modes = analyze_vibrational_modes(opt_st, h_arr)
                            ok, reasons = validate_transition_state_modes(opt_st, modes)
                            if not ok:
                                raise RuntimeError(f"TS validation failed for {node.node_id}: {reasons}")
                        else:
                            opt_st, e_ha = optimize_ground_state(st, engine)
                            h_arr = None
                        self.store.put(
                            key,
                            stg,
                            {
                                "optimized_state": opt_st.model_dump(mode="json"),
                                "electronic_energy_hartree": e_ha,
                                "hessian_hartree_per_bohr2": h_arr.tolist() if h_arr is not None else None,
                            },
                        )
                    next_states.append(opt_st)
                    next_energies.append(e_ha)
                    next_hess.append(h_arr)
                cur_states = next_states
                latest_energies = next_energies
                latest_hessians = next_hess

            elif stg.stage == StageKind.FREQUENCY:
                next_hess = []
                for idx, st in enumerate(cur_states):
                    key = StageCacheKey.build(st, stg)
                    cached = self.store.get(key)
                    if cached is not None:
                        self.cache_hits += 1
                        h_arr = np.asarray(cached["hessian_hartree_per_bohr2"], dtype=np.float64)
                    else:
                        self.cache_misses += 1
                        res = engine.evaluate(st, compute_forces=False, compute_hessian=True)
                        h_arr = np.asarray(res.hessian_hartree_per_bohr2, dtype=np.float64)
                        self.store.put(
                            key,
                            stg,
                            {"hessian_hartree_per_bohr2": h_arr.tolist()},
                        )
                    next_hess.append(h_arr)
                latest_hessians = next_hess

            elif stg.stage == StageKind.SINGLE_POINT:
                sp_energies: list[float] = []
                for st in cur_states:
                    key = StageCacheKey.build(st, stg)
                    cached = self.store.get(key)
                    if cached is not None:
                        self.cache_hits += 1
                        e_ha = float(cached["electronic_energy_hartree"])
                    else:
                        self.cache_misses += 1
                        res = engine.evaluate(st, compute_forces=False, compute_hessian=False)
                        e_ha = res.electronic_energy_hartree
                        self.store.put(key, stg, {"electronic_energy_hartree": e_ha})
                    sp_energies.append(e_ha)
                latest_energies = sp_energies

        # Assemble final Gibbs free energies across conformers
        gibbs_list: list[float] = []
        for idx, st in enumerate(cur_states):
            e_elec = latest_energies[idx]
            h_mat = latest_hessians[idx]
            if h_mat is not None:
                thermo = compute_thermochemistry(
                    st,
                    e_elec,
                    h_mat,
                    config=graph.thermo,
                    expect_transition_state=is_ts,
                )
                gibbs_list.append(thermo.gibbs_free_energy_hartree)
            else:
                gibbs_list.append(e_elec)

        ens = build_boltzmann_ensemble(
            node.node_id,
            cur_states,
            gibbs_list,
            temperature_k=graph.thermo.temperature_k,
        )
        return ens.boltzmann_averaged_gibbs_hartree

    def run(self, graph: ReactionGraph) -> WorkflowExecutionReport:
        """Execute ReactionGraph by priority tier, evaluating pruning gates between tiers."""
        ordered = graph.execution_order()
        tiers = sorted({n.priority for n in ordered})

        node_gibbs: dict[str, float] = {}
        completed: list[str] = []
        skipped: list[str] = []
        all_pruning_msgs: list[str] = []
        aborted = False

        for tier in tiers:
            tier_nodes = [n for n in ordered if n.priority == tier]
            if aborted:
                skipped.extend(n.node_id for n in tier_nodes)
                continue

            for node in tier_nodes:
                g_ha = self._run_node(graph, node)
                node_gibbs[node.node_id] = g_ha
                completed.append(node.node_id)

            should_skip, msgs = evaluate_pruning_rules(
                graph.pruning_rules,
                node_gibbs,
                temperature_k=graph.thermo.temperature_k,
            )
            all_pruning_msgs.extend(msgs)
            if should_skip:
                aborted = True

        return WorkflowExecutionReport(
            graph_name=graph.name,
            node_gibbs_hartree=node_gibbs,
            completed_nodes=completed,
            skipped_nodes=skipped,
            cache_hits=self.cache_hits,
            cache_misses=self.cache_misses,
            pruning_messages=all_pruning_msgs,
        )
