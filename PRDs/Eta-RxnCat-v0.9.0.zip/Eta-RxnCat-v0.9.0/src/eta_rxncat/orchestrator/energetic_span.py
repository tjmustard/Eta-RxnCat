"""Kozuch-Shaik Energetic Span Model (TOF, TDI, TDTS) and sum-over-states turnover rate."""

from __future__ import annotations

import math

import numpy as np
from pydantic import BaseModel

HARTREE_TO_KCAL_MOL = 627.5094740631
KB_J_K = 1.380649e-23
PLANCK_J_S = 6.62607015e-34
R_KCAL_MOL_K = 0.00198720425864083


class EnergeticSpanResult(BaseModel):
    """Turnover frequency and turnover-determining states for a catalytic cycle."""

    energetic_span_kcal: float
    tof_esm_s_inv: float
    tof_sum_over_states_s_inv: float
    tdi_node_id: str
    tdts_node_id: str


def compute_energetic_span(
    intermediate_ids: list[str],
    intermediate_gibbs_ha: list[float],
    ts_ids: list[str],
    ts_gibbs_ha: list[float],
    delta_g_rxn_kcal: float,
    temperature_k: float = 298.15,
) -> EnergeticSpanResult:
    """Compute exact sum-over-states TOF and approximate Energetic Span Model TOF (Kozuch & Shaik)."""
    if len(intermediate_ids) != len(intermediate_gibbs_ha) or len(ts_ids) != len(ts_gibbs_ha):
        raise ValueError("State ID lists and Gibbs energy lists must have identical lengths.")
    if not intermediate_ids or not ts_ids:
        raise ValueError("Catalytic cycle requires at least one intermediate and one transition state.")

    i_kcal = np.asarray(intermediate_gibbs_ha, dtype=np.float64) * HARTREE_TO_KCAL_MOL
    t_kcal = np.asarray(ts_gibbs_ha, dtype=np.float64) * HARTREE_TO_KCAL_MOL
    rt = R_KCAL_MOL_K * temperature_k
    kbt_h = (KB_J_K * temperature_k) / PLANCK_J_S

    n_i = len(i_kcal)
    n_t = len(t_kcal)
    span_matrix = np.zeros((n_t, n_i), dtype=np.float64)

    for idx_t in range(n_t):
        for idx_i in range(n_i):
            # Standard catalytic cycle convention: TS_j follows Intermediate_j (idx_t >= idx_i)
            delta_g_rxn_term = 0.0 if idx_t >= idx_i else delta_g_rxn_kcal
            span_matrix[idx_t, idx_i] = t_kcal[idx_t] - i_kcal[idx_i] + delta_g_rxn_term

    max_flat = int(np.argmax(span_matrix))
    best_t_idx, best_i_idx = divmod(max_flat, n_i)
    d_e = float(span_matrix[best_t_idx, best_i_idx])

    tof_esm = kbt_h * math.exp(-min(d_e / rt, 500.0))

    # Exact sum-over-states denominator
    denom = float(np.sum(np.exp(np.minimum(span_matrix / rt, 500.0))))
    num = math.exp(-min(delta_g_rxn_kcal / rt, 500.0))
    tof_sos = kbt_h * (1.0 - num) / max(denom, 1e-300)

    return EnergeticSpanResult(
        energetic_span_kcal=d_e,
        tof_esm_s_inv=tof_esm,
        tof_sum_over_states_s_inv=max(tof_sos, 0.0),
        tdi_node_id=intermediate_ids[best_i_idx],
        tdts_node_id=ts_ids[best_t_idx],
    )
