"""Unit tests for v1.0.0 CLI subcommands and PotentialEngine registry."""

from pathlib import Path

from eta_rxncat.cli import main
from eta_rxncat.core.models import SolvationSpec, StageConfig, StageKind
from eta_rxncat.engines.registry import build_engine


def test_engine_registry_builds_all_v1_backends() -> None:
    assert build_engine(StageConfig(stage=StageKind.GEOMETRY_OPT, engine="rdkit_ff", method="UFF")).name == "rdkit_uff"
    assert build_engine(StageConfig(stage=StageKind.SINGLE_POINT, engine="xtb", method="GFN2-xTB")).name == "xtb_gfn2-xtb"
    assert build_engine(StageConfig(stage=StageKind.SINGLE_POINT, engine="mace", method="medium")).name == "mace_medium"
    assert build_engine(StageConfig(stage=StageKind.SINGLE_POINT, engine="uma", method="uma-s-1.2.1")).name == "uma_uma-s-1.2.1"
    pyscf_eng = build_engine(
        StageConfig(
            stage=StageKind.SINGLE_POINT,
            engine="pyscf",
            method="wB97X-D3BJ",
            basis="def2-SVP",
            solvation=SolvationSpec(model="ddcosmo", solvent="toluene"),
        )
    )
    assert pyscf_eng.name == "pyscf_wB97X-D3BJ_def2-SVP"


def test_cli_validate_and_cache_status(tmp_path: Path) -> None:
    fixture = Path("tests/e2e/fixtures/example_reaction_graph.yaml")
    if fixture.exists():
        assert main(["validate", str(fixture)]) == 0
    assert main(["cache-status", "--cache-db", str(tmp_path / "missing.sqlite")]) == 0
