"""Production v1.0.0 Command-Line Interface for Eta-RxnCat."""

from __future__ import annotations

import argparse
import json
import sqlite3
import sys
from pathlib import Path

from eta_rxncat.core.reaction_graph import ReactionGraph
from eta_rxncat.engines.registry import build_engine
from eta_rxncat.mapping.enumerator import SubstituentCandidate, enumerate_reaction_graphs
from eta_rxncat.orchestrator.scheduler import GraphOrchestrator
from eta_rxncat.store.artifact_store import ArtifactStore
from eta_rxncat.utils.hw_probe import probe_hardware


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="eta-rxncat",
        description="Eta-RxnCat computational catalysis workflow engine (v1.0.0)",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("hardware-check", help="Inspect CUDA, PyTorch, and GPU4PySCF capabilities")

    val_p = sub.add_parser("validate", help="Validate a ReactionGraph YAML or JSON file")
    val_p.add_argument("graph_file", type=Path, help="Path to reaction graph (.yaml/.yml/.json)")

    enum_p = sub.add_parser("enumerate", help="Enumerate a reference ReactionGraph across a substituent JSON library")
    enum_p.add_argument("graph_file", type=Path, help="Path to reference reaction graph (.yaml/.yml/.json)")
    enum_p.add_argument("library_json", type=Path, help="Path to JSON list of SubstituentCandidate objects")
    enum_p.add_argument("--out-dir", type=Path, default=Path("enumerated_graphs"), help="Output directory for generated YAMLs")

    run_p = sub.add_parser("run", help="Execute a ReactionGraph workflow with stage-decomposed caching")
    run_p.add_argument("graph_file", type=Path, help="Path to reaction graph (.yaml/.yml/.json)")
    run_p.add_argument(
        "--cache-db",
        type=Path,
        default=Path(".eta_cache/artifacts.sqlite"),
        help="Path to SQLite artifact cache database",
    )
    run_p.add_argument("--output-json", type=Path, default=None, help="Optional JSON report path")

    cache_p = sub.add_parser("cache-status", help="Inspect completed stage counts in the artifact store")
    cache_p.add_argument(
        "--cache-db",
        type=Path,
        default=Path(".eta_cache/artifacts.sqlite"),
        help="Path to SQLite artifact cache database",
    )

    args = parser.parse_args(argv)

    if args.command == "hardware-check":
        report = probe_hardware()
        print(json.dumps(report.model_dump(), indent=2))
        return 0

    if args.command == "validate":
        graph = ReactionGraph.from_file(args.graph_file)
        order = graph.execution_order()
        print(
            f"Valid ReactionGraph '{graph.name}' "
            f"({len(graph.nodes)} nodes, {len(graph.edges)} edges). "
            f"Priority execution order: {[n.node_id for n in order]}"
        )
        return 0

    if args.command == "enumerate":
        ref_graph = ReactionGraph.from_file(args.graph_file)
        raw_lib = json.loads(args.library_json.read_text(encoding="utf-8"))
        candidates = [SubstituentCandidate.model_validate(item) for item in raw_lib]
        graphs = enumerate_reaction_graphs(ref_graph, candidates)
        args.out_dir.mkdir(parents=True, exist_ok=True)
        for g in graphs:
            (args.out_dir / f"{g.name}.yaml").write_text(g.to_yaml(), encoding="utf-8")
        print(f"Generated {len(graphs)} enumerated ReactionGraph YAML files in {args.out_dir}")
        return 0

    if args.command == "run":
        graph = ReactionGraph.from_file(args.graph_file)
        store = ArtifactStore(args.cache_db)
        orchestrator = GraphOrchestrator(engine_factory=build_engine, store=store)
        report = orchestrator.run(graph)
        rendered = json.dumps(report.model_dump(), indent=2)
        if args.output_json is not None:
            args.output_json.write_text(rendered, encoding="utf-8")
        print(rendered)
        return 0

    if args.command == "cache-status":
        db: Path = args.cache_db
        if not db.exists():
            print(json.dumps({"cache_db": str(db), "exists": False, "completed_stages": 0}, indent=2))
            return 0
        with sqlite3.connect(db) as conn:
            rows = conn.execute(
                "SELECT stage_kind, engine, COUNT(*) FROM stage_artifacts WHERE status = 'completed' GROUP BY stage_kind, engine"
            ).fetchall()
        summary = [{"stage": r[0], "engine": r[1], "count": r[2]} for r in rows]
        print(json.dumps({"cache_db": str(db), "exists": True, "breakdown": summary}, indent=2))
        return 0

    return 1


if __name__ == "__main__":
    sys.exit(main())
