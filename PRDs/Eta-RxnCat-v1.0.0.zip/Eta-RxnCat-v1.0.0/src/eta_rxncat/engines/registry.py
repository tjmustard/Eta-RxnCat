"""Factory resolving StageConfig into concrete clean-room PotentialEngine instances."""

from __future__ import annotations

from eta_rxncat.core.models import StageConfig
from eta_rxncat.engines.base import PotentialEngine
from eta_rxncat.engines.mlip import MACEEngine, UMADirectEngine
from eta_rxncat.engines.pyscf_engine import PySCFEngine
from eta_rxncat.engines.rdkit_xtb import RDKitFFEngine, XTBSubprocessEngine


def build_engine(stage: StageConfig) -> PotentialEngine:
    """Instantiate the configured PotentialEngine from a StageConfig."""
    if stage.engine == "rdkit_ff":
        ff = "UFF" if stage.method.upper() not in {"MMFF94", "MMFF94S"} else stage.method.upper()
        return RDKitFFEngine(force_field=ff)  # type: ignore[arg-type]

    if stage.engine == "xtb":
        method = "GFN2-xTB" if stage.method not in {"GFN1-xTB", "GFN-FF"} else stage.method
        return XTBSubprocessEngine(method=method, solvation=stage.solvation)  # type: ignore[arg-type]

    if stage.engine == "mace":
        model = "medium" if stage.method == "default" else stage.method
        return MACEEngine(model_name=model)

    if stage.engine == "uma":
        model = "uma-s-1.2.1" if stage.method == "default" else stage.method
        task = str(stage.extra_options.get("task_name", "omol"))
        return UMADirectEngine(model_name=model, task_name=task)

    if stage.engine == "pyscf":
        func = "wB97X-D3BJ" if stage.method == "default" else stage.method
        basis = stage.basis or "def2-SVP"
        prefer_gpu = bool(stage.extra_options.get("prefer_gpu", True))
        return PySCFEngine(
            functional=func,
            basis=basis,
            solvation=stage.solvation,
            prefer_gpu=prefer_gpu,
        )

    raise ValueError(f"Unknown engine: {stage.engine}")
