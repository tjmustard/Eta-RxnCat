"""Eta-RxnCat: Clean-room computational catalysis and reaction mechanism profiling."""

__version__ = "1.0.0"
